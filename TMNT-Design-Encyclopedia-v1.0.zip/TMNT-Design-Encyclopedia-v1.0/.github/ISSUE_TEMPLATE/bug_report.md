Bug template
