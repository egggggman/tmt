Feature template
